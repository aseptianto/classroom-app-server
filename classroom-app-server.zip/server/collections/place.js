/*
Meteor.publish('places', function(){
    return Place.find({});
});
*/
